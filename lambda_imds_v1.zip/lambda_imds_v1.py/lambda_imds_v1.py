import boto3
import os
from datetime import datetime
import cfnresponse
import json


remediation = "metadata-version-2"
accountId = os.environ['accountId']

def change_metadata_version(client_ec2,ec2_noncompliance,bucket_s3):
    try:
        #verify if metadata service is enabled
        response = client_ec2.describe_instances(
            InstanceIds=[ec2_noncompliance,]
        )
        if response['Reservations'][0]['Instances'][0]['MetadataOptions']['HttpEndpoint'] == 'enabled': 
            if response['Reservations'][0]['Instances'][0]['MetadataOptions']['HttpTokens'] == 'optional':
                #modify metadata version to 2
                response_change_imdsv2 = client_ec2.modify_instance_metadata_options(
                    InstanceId=ec2_noncompliance,
                    HttpTokens='required',
                    HttpEndpoint='enabled'
                )
                print('IMDS changed in {} to Version 2'.format(ec2_noncompliance))
                if response_change_imdsv2['ResponseMetadata']['HTTPStatusCode'] == 200:
                    date=datetime.now()
                    date=str(date.strftime("%Y-%m-%d %H:%M"))
                    content = {"InstanceID": ec2_noncompliance, "Time of Change": date }
                    content = json.dumps(content)
                    with open ("/tmp/{}_{}.json".format(ec2_noncompliance,date), "w+") as f:
                        f.write(content)
                    client_s3= boto3.client('s3')
                    response_s3 = client_s3.upload_file("/tmp/{}_{}.json".format(ec2_noncompliance,date),"{}".format(bucket_s3), accountId + remediation + "{}_{}.json".format(ec2_noncompliance,date))
        else:
            print('Meta Data service disable on instance {}. This resource was not changed.'.format(ec2_noncompliance))    
        return None
    except Exception as e:
        print("Failed to modify instance: {} to meta data service version 2. Error msg: {}".format(ec2_noncompliance,e))


def verify_ec2tag_exclusion(client_ec2,ec2_noncompliance,tag_exclusion,bucket_s3):
    try:
        response = client_ec2.describe_tags(
            Filters=[
                {
                    'Name': 'resource-id',
                    'Values': [
                        ec2_noncompliance,
                    ],
                },
            ],
        )
        tags_to_check = response['Tags']
        while "NextToken" in response:
            response = client_ec2.describe_tags(
            Filters=[
                {
                    'Name': 'resource-id',
                    'Values': [
                        ec2_noncompliance,
                    ],
                },
            ],
            NextToken=response['NextToken']
            )
            tags_to_check.extend(response['Tags'])
        for tag_to_check in tags_to_check:
            if tag_exclusion == tag_to_check['Key']:
                #verify if instance metadata is on version2
                #verify if metadata service is enabled
                response = client_ec2.describe_instances(
                    InstanceIds=[ec2_noncompliance,]
                )
                if response['Reservations'][0]['Instances'][0]['MetadataOptions']['HttpEndpoint'] == 'enabled' and response['Reservations'][0]['Instances'][0]['MetadataOptions']['HttpTokens'] == 'required':
                    #There is tag for exclusion of automation and version is 2. This will modify metadata version to 1
                    response_change_imdsv1 = client_ec2.modify_instance_metadata_options(
                    InstanceId=ec2_noncompliance,
                    HttpTokens='optional',
                    HttpEndpoint='enabled'
                    )
                    if response_change_imdsv1['ResponseMetadata']['HTTPStatusCode'] == 200:
                        date=datetime.now()
                        date=str(date.strftime("%Y-%m-%d %H:%M"))
                        content = {"InstanceID": ec2_noncompliance, "Time of Rollback": date }
                        content = json.dumps(content)
                        with open ("/tmp/ROLLBACK_to_V1_{}_{}.json".format(ec2_noncompliance,date), "w+") as f:
                            f.write(content)
                        client_s3= boto3.client('s3')
                        response_s3 = client_s3.upload_file("/tmp/ROLLBACK_to_V1_{}_{}.json".format(ec2_noncompliance,date),"{}".format(bucket_s3), "ROLLBACK_to_V1_{}_{}.json".format(ec2_noncompliance,date))
                        print("This instance: {} was executed a rollback because. It was set with the tag of exclusion: {} and this instance was running on Version2 of metadata ".format(ec2_noncompliance,tag_exclusion))
                        return True
                else:
                    #There is tag for exclusion of automation and version is 1
                    print("This instance: {} will not be remedied because. The tag of exclusion: {} is set ".format(ec2_noncompliance,tag_exclusion))
                    return True
        return False    
    except Exception as e:
        print("Failed to get TAG information from this: {} EC2. Error msg: {}".format(ec2_noncompliance,e))


def change_imdsv2(event):
    tag_exclusion = os.environ['Tag_exclusion']
    bucket_s3 = os.environ['bucket_s3']
    try:
        #Create client_ec2 to ec2
        client_ec2 = boto3.client('ec2')
        #Parse information about which ec2 is not compliance
        ec2_noncompliance = event["detail"]["resourceId"]
        #Verify Tag to check if necessary exclude this item of change version.
        if verify_ec2tag_exclusion(client_ec2,ec2_noncompliance,tag_exclusion,bucket_s3):
            return None
        else:
            #change meta data version to V2 
            change_metadata_version(client_ec2,ec2_noncompliance,bucket_s3)
            return None    
    except Exception as e:
        print("Failed to parse information about EC2. Error msg: {}".format(e))


def verify_itens_config_rule(config_rule):
    try:
        #List old itens on config rule.
        client_config = boto3.client("config")
        response = client_config.get_compliance_details_by_config_rule(
            ConfigRuleName=config_rule,
            ComplianceTypes=['NON_COMPLIANT','COMPLIANT']
            )
        instances_non_compliance = response['EvaluationResults']
        while "NextToken" in response:
            response = client_config.get_compliance_details_by_config_rule(
                ConfigRuleName=config_rule,
                ComplianceTypes=['NON_COMPLIANT','COMPLIANT'],
                NextToken=response['NextToken']
                )
            instances_non_compliance.extend(response['EvaluationResults'])
        for instance_non_compliance in instances_non_compliance:
            #Prepare payload to invoke verification of tag and call to modify metadata version
            event = {"detail": {"resourceId": instance_non_compliance['EvaluationResultIdentifier']['EvaluationResultQualifier']['ResourceId'],"newEvaluationResult": {"complianceType":instance_non_compliance['ComplianceType']} }}
            change_imdsv2(event)
    except Exception as e:
        print("Failed to verify old itens in config rule: {} . Error msg: {}".format(config_rule,e))

def start_config(event,context):
    #Verify items on first run to remediation old items on rule
    if "RequestType" in event:
        config_rule = os.environ['config_rule_account_metadatav2']
        verify_itens_config_rule(config_rule)
        responseData = {'Data': 'Invoke OK!'}
        cfnresponse.send(event, context, cfnresponse.SUCCESS, responseData)
    elif "version" in event:
        change_imdsv2(event)
    else:
        config_rule = os.environ['config_rule_account_metadatav2']
        verify_itens_config_rule(config_rule)
    return None